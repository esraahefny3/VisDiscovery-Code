
package result;

/**
 *
 * @author omarkrostom
 */
public class Encoding {
    Column column;
    Column y;
    xAxisFormatter x;
    Column color;
	public Column getColumn() {
		return column;
	}
	public void setColumn(Column column) {
		this.column = column;
	}
	public Column getY() {
		return y;
	}
	public void setY(Column y) {
		this.y = y;
	}
	public xAxisFormatter getX() {
		return x;
	}
	public void setX(xAxisFormatter x) {
		this.x = x;
	}
	public Column getColor() {
		return color;
	}
	public void setColor(Column color) {
		this.color = color;
	}
}
