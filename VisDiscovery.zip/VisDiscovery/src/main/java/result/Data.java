package result;

import java.util.ArrayList;

import recommendation.VisObject;

/**
*
* @author nada
*/


public class Data {
	
	ArrayList<VisObject> values = new ArrayList<VisObject>();
	
	public ArrayList<VisObject> getValues() {
		return values;
	}
	public void setValues(ArrayList<VisObject> values) {
		this.values = values;
	}

}
