package recommendation;


/**
 *
 * @author ninja
 */
public class VisObject {

    public String xAxis;
    public String yAxis;
    public int queryNumber;

}
